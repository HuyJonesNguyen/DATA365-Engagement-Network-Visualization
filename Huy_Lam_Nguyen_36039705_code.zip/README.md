|id |course_title |
|2 |Introduction to Tableau |
|3 |The Complete Data Visualization Course with Python, R, Tableau, and Excel |
|4 |Introduction to R Programming |
|5 |Data Preprocessing with NumPy |
|7 |Introduction to Data and Data Science |
|11 |Data Cleaning and Preprocessing with pandas |
|12 |Introduction to Business Analytics |
|13 |Data Analysis with Excel Pivot Tables |
|14 |SQL |
|15 |Credit Risk Modeling in Python |
|16 |Python Programmer Bootcamp |
|19 |SQL + Tableau + Python |
|20 |Introduction to Jupyter |
|21 |Statistics |
|22 |Mathematics |
|23 |Introduction to Excel |
|24 |Probability |
|25 |Starting a Career in Data Science: Project Portfolio, Resume, and Interview Process|
|26 |SQL + Tableau |
|27 |Time Series Analysis with Python |
|28 |Power BI |
|29 |Product Management for AI & Data Science |
|30 |Git and GitHub |
|32 |Deep Learning with TensorFlow 2 |
|33 |Customer Analytics in Python |
|34 |Web Scraping and API Fundamentals in Python |
|35 |Introduction to Python |
|36 |Python for Finance |
|37 |Machine Learning in Python |
|39 |Advanced Microsoft Excel |
|41 |Convolutional Neural Networks with TensorFlow in Python |
|42 |Data Strategy |
|43 |Fashion Analytics with Tableau |
|44 |Dates and Times in Python |
|45 |SQL for Data Science Interviews |
|46 |Data Literacy |
|48 |AI Applications for Business Success |
|49 |Linear Algebra and Feature Selection |
|50 |Machine Learning with Naive Bayes |
|51 |Machine Learning in Excel |
|52 |Machine Learning with Support Vector Machines |
|53 |A/B Testing in Python |
|54 |Machine Learning with Decision Trees and Random Forests |
|55 |Machine Learning with K-Nearest Neighbors |
|56 |Machine Learning with Ridge and Lasso Regression |
|57 |Data-Driven Business Growth |
|59 |Marketing Strategy |
|60 |Negotiation |
|66 |Blockchain for Business |
|67 |How to Think Like a Data Scientist to Become One |
